# CodeHost - Bot Development Platform

## Overview

CodeHost is a full-stack web application for building, deploying, and hosting Telegram bots and programming scripts. It features an integrated code editor, project management system, and deployment capabilities with a modern React frontend and Express.js backend.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit OpenID Connect (OIDC) integration
- **Session Management**: Express session with PostgreSQL store
- **Build System**: ESBuild for production bundling
- **Development**: TSX for TypeScript execution in development

### Database Schema
The application uses PostgreSQL with the following core entities:
- **Users**: User profiles with OIDC integration
- **Sessions**: Session storage for authentication (required for Replit Auth)
- **Projects**: User projects with language, status, deployment settings, and performance metrics
- **Project Files**: File storage for project source code with active file tracking
- **Admin Logs**: Activity tracking for project owners with action history and details

## Key Components

### Authentication System
- Implements Replit OIDC for seamless authentication
- Passport.js strategy for OpenID Connect
- Session-based authentication with PostgreSQL storage
- Protected routes and API endpoints

### Project Management
- Create projects with multiple programming languages
- File management with active file tracking
- Project status management (running, stopped, building)
- Environment variable configuration
- Custom domain and deployment provider settings

### Code Editor Interface
- Multi-tab file editing
- Syntax highlighting and code completion
- Console output for running scripts
- File tree navigation
- Real-time project status updates

### Admin Panel (Project Owner Only)
- Project status monitoring and resource usage tracking
- Activity logs with detailed action history
- Admin controls for restart and force operations
- Project statistics including total runs and last activity
- Owner-only access verification and security controls

### Deployment Integration
- Railway deployment provider support
- Environment variable management
- Custom domain configuration
- Bot token management for Telegram bots

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit OIDC, sessions stored in PostgreSQL
2. **Project Creation**: Users create projects with specified language and configuration
3. **File Management**: Files are created/updated through the API with content stored in database
4. **Code Execution**: Projects can be run with output captured and displayed
5. **Deployment**: Projects can be deployed to configured providers with environment variables

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection via Neon
- **drizzle-orm**: Type-safe ORM for database operations
- **passport**: Authentication middleware
- **openid-client**: OpenID Connect client implementation
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework

### Development Dependencies
- **vite**: Frontend build tool and dev server
- **tsx**: TypeScript execution for development
- **esbuild**: JavaScript bundler for production
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Development Environment
- Vite dev server for frontend with HMR
- TSX for backend TypeScript execution
- PostgreSQL database with Drizzle migrations
- Replit-specific development tooling

### Production Build Process
1. Frontend: Vite builds React app to `dist/public`
2. Backend: ESBuild bundles server code to `dist/index.js`
3. Database: Drizzle pushes schema changes to PostgreSQL
4. Deployment: Single Node.js process serves both frontend and API

### Infrastructure Requirements
- Node.js 20+ runtime environment
- PostgreSQL 16+ database
- Environment variables for database URL and session secrets
- HTTPS for secure authentication flows

## Changelog
- June 26, 2025: Added comprehensive admin panel with project monitoring, activity logs, and owner-only controls
- June 26, 2025: Enhanced database schema with admin logs tracking and project statistics
- June 26, 2025: Implemented project owner verification and admin-specific API endpoints
- June 26, 2025: Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.