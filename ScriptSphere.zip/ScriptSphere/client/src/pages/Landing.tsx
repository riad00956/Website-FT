import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Code, Bot, Rocket, Shield } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                <Code className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">CodeHost</span>
            </div>
            <Button onClick={() => window.location.href = "/api/login"}>
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Build, Deploy, and Host Your Bots
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Create unlimited Telegram bots and programming scripts with our integrated code editor. 
            Deploy instantly to the cloud with zero configuration.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Button size="lg" onClick={() => window.location.href = "/api/login"}>
              Get Started Free
            </Button>
            <Button variant="outline" size="lg">
              View Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-6 py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Everything You Need to Build</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Code className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Integrated Code Editor</CardTitle>
                <CardDescription>
                  Full-featured Monaco editor with syntax highlighting, autocomplete, and error detection
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                  <Bot className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle>Telegram Bot Support</CardTitle>
                <CardDescription>
                  Built-in templates and configuration for Telegram bots with token management
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Rocket className="w-6 h-6 text-green-500" />
                </div>
                <CardTitle>One-Click Deploy</CardTitle>
                <CardDescription>
                  Deploy to Railway, Firebase, or Vercel with a single click. No DevOps required
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-orange-500" />
                </div>
                <CardTitle>Secure Environment</CardTitle>
                <CardDescription>
                  Environment variables and API keys are encrypted and securely stored
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Code className="w-6 h-6 text-purple-500" />
                </div>
                <CardTitle>Multi-Language</CardTitle>
                <CardDescription>
                  Support for Python, JavaScript, HTML/CSS, and more languages coming soon
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Code className="w-6 h-6 text-blue-500" />
                </div>
                <CardTitle>Custom Domains</CardTitle>
                <CardDescription>
                  Get a free subdomain or connect your own custom domain for professional hosting
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Building?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of developers who trust CodeHost for their bot and script hosting needs.
          </p>
          <Button size="lg" onClick={() => window.location.href = "/api/login"}>
            Start Coding Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
                <Code className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-semibold">CodeHost</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 CodeHost. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
