import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Bell, Menu, Moon, Sun, Code, LogOut, Shield, Settings } from "lucide-react";
import ProjectList from "@/components/ProjectList";
import CodeEditor from "@/components/CodeEditor";
import SettingsPanel from "@/components/SettingsPanel";
import AdminPanel from "@/components/AdminPanel";
import type { Project } from "@shared/schema";

export default function Dashboard() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    // Close sidebar on mobile when project is selected
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                <Code className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">CodeHost</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {selectedProject && (
              <div className="flex items-center space-x-2 border-l border-border pl-4">
                <Button 
                  variant={!showAdminPanel ? "secondary" : "ghost"} 
                  size="sm"
                  onClick={() => setShowAdminPanel(false)}
                >
                  <Settings className="w-4 h-4 mr-1" />
                  Settings
                </Button>
                <Button 
                  variant={showAdminPanel ? "secondary" : "ghost"} 
                  size="sm"
                  onClick={() => setShowAdminPanel(true)}
                >
                  <Shield className="w-4 h-4 mr-1" />
                  Admin
                </Button>
              </div>
            )}
            <Button variant="ghost" size="sm">
              <Bell className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={toggleTheme}>
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <div className="flex items-center space-x-3">
              {user && (user as any).profileImageUrl && (
                <img 
                  src={(user as any).profileImageUrl} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full object-cover border-2 border-transparent hover:border-primary transition-colors cursor-pointer" 
                />
              )}
              <span className="hidden md:block text-sm font-medium">
                {user && (user as any).firstName ? `${(user as any).firstName}${(user as any).lastName ? ` ${(user as any).lastName}` : ''}` : user && (user as any).email}
              </span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-73px)]">
        {/* Sidebar */}
        <aside className={`w-64 bg-card border-r border-border transform transition-transform duration-200 ease-in-out fixed lg:relative z-40 h-full ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}>
          <nav className="p-4 space-y-2">
            <a href="#" className="flex items-center space-x-3 px-3 py-2 bg-primary/10 text-primary rounded-md font-medium">
              <Code className="w-5 h-5" />
              <span>Dashboard</span>
            </a>
            <a href="#" className="flex items-center space-x-3 px-3 py-2 text-muted-foreground hover:bg-muted rounded-md">
              <Code className="w-5 h-5" />
              <span>Projects</span>
            </a>
            <a href="#" className="flex items-center space-x-3 px-3 py-2 text-muted-foreground hover:bg-muted rounded-md">
              <Code className="w-5 h-5" />
              <span>Bots</span>
            </a>
            <a href="#" className="flex items-center space-x-3 px-3 py-2 text-muted-foreground hover:bg-muted rounded-md">
              <Code className="w-5 h-5" />
              <span>Deployments</span>
            </a>
            <a href="#" className="flex items-center space-x-3 px-3 py-2 text-muted-foreground hover:bg-muted rounded-md">
              <Code className="w-5 h-5" />
              <span>Settings</span>
            </a>
          </nav>
        </aside>

        {/* Overlay for mobile sidebar */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full flex">
            <ProjectList 
              selectedProject={selectedProject} 
              onSelectProject={handleSelectProject} 
            />
            <CodeEditor project={selectedProject} />
            {showAdminPanel ? (
              <AdminPanel project={selectedProject} />
            ) : (
              <SettingsPanel project={selectedProject} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
