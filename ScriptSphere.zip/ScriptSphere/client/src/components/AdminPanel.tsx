import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Shield, 
  Activity, 
  Server, 
  RotateCcw, 
  Play, 
  Square, 
  Clock, 
  Cpu, 
  HardDrive,
  Users,
  AlertTriangle,
  CheckCircle,
  Info
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Project, AdminLog } from "@shared/schema";

interface AdminPanelProps {
  project: Project | null;
}

interface ProjectStats {
  totalRuns: number;
  lastActivity: Date | null;
  memoryUsage: string | null;
  cpuUsage: string | null;
}

export default function AdminPanel({ project }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch admin logs
  const { data: logs = [] } = useQuery<AdminLog[]>({
    queryKey: ["/api/projects", project?.id, "admin", "logs"],
    enabled: !!project?.id,
  });

  // Fetch project stats
  const { data: stats } = useQuery<ProjectStats>({
    queryKey: ["/api/projects", project?.id, "admin", "stats"],
    enabled: !!project?.id,
  });

  // Restart project mutation
  const restartMutation = useMutation({
    mutationFn: async () => {
      if (!project) throw new Error("No project selected");
      const response = await apiRequest("POST", `/api/projects/${project.id}/admin/restart`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "admin"] });
      toast({ title: "Project restarted", description: "Your project is restarting..." });
    },
    onError: (error) => {
      toast({ title: "Restart failed", description: error.message, variant: "destructive" });
    },
  });

  const formatTimeAgo = (date: string | Date | null) => {
    if (!date) return "Never";
    const now = new Date();
    const past = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - past.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case "deploy": return <Play className="w-4 h-4 text-green-500" />;
      case "stop": return <Square className="w-4 h-4 text-red-500" />;
      case "restart": return <RotateCcw className="w-4 h-4 text-blue-500" />;
      case "file_updated": return <Info className="w-4 h-4 text-blue-500" />;
      case "settings_changed": return <Info className="w-4 h-4 text-yellow-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running": return "text-green-600 dark:text-green-400";
      case "building": return "text-yellow-600 dark:text-yellow-400";
      case "stopped": return "text-gray-600 dark:text-gray-400";
      default: return "text-gray-600 dark:text-gray-400";
    }
  };

  if (!project) {
    return (
      <div className="w-80 bg-card border-l border-border p-4">
        <div className="text-center text-muted-foreground">
          <Shield className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">Admin Panel</h3>
          <p className="text-sm">Select a project to view admin controls</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border overflow-y-auto">
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2 mb-4">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Admin Panel</h3>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
            <TabsTrigger value="logs" className="text-xs">Logs</TabsTrigger>
            <TabsTrigger value="controls" className="text-xs">Controls</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            {/* Project Status */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <Server className="w-4 h-4" />
                  <span>Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Current Status</span>
                  <Badge variant="outline" className={getStatusColor(project.status)}>
                    {project.status}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Total Runs</span>
                  <span className="text-sm font-medium">{stats?.totalRuns || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Last Activity</span>
                  <span className="text-sm text-muted-foreground">
                    {formatTimeAgo(stats?.lastActivity || null)}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Resource Usage */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <Activity className="w-4 h-4" />
                  <span>Resources</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Cpu className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">CPU Usage</span>
                  </div>
                  <span className="text-sm font-medium">
                    {stats?.cpuUsage || "0%"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <HardDrive className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Memory</span>
                  </div>
                  <span className="text-sm font-medium">
                    {stats?.memoryUsage || "0 MB"}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => restartMutation.mutate()}
                  disabled={restartMutation.isPending}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  {restartMutation.isPending ? "Restarting..." : "Restart Project"}
                </Button>
                {project.deploymentUrl && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-start"
                    asChild
                  >
                    <a href={project.deploymentUrl} target="_blank" rel="noopener noreferrer">
                      <Server className="w-4 h-4 mr-2" />
                      View Live Site
                    </a>
                  </Button>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="logs" className="space-y-4">
            <ScrollArea className="h-80">
              <div className="space-y-2">
                {logs.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    <Activity className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm">No activity logs yet</p>
                  </div>
                ) : (
                  logs.map((log) => (
                    <Card key={log.id} className="p-3">
                      <div className="flex items-start space-x-3">
                        {getActionIcon(log.action)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium capitalize">
                              {log.action.replace('_', ' ')}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {formatTimeAgo(log.timestamp)}
                            </span>
                          </div>
                          {log.details && typeof log.details === 'object' && Object.keys(log.details as object).length > 0 && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {String(JSON.stringify(log.details, null, 0)).slice(0, 50)}...
                            </p>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="controls" className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                  <span>Admin Controls</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
                  <div className="flex items-center space-x-2">
                    <Info className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                    <p className="text-xs text-yellow-700 dark:text-yellow-300">
                      Only project owners can access these controls
                    </p>
                  </div>
                </div>
                
                <Button 
                  variant="destructive" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => restartMutation.mutate()}
                  disabled={restartMutation.isPending}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Force Restart
                </Button>
                
                <div className="pt-2">
                  <h4 className="text-xs font-medium mb-2">Project Information</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Project ID</span>
                      <span className="font-mono">{project.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Language</span>
                      <span className="capitalize">{project.language}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Created</span>
                      <span>{new Date(project.createdAt!).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}