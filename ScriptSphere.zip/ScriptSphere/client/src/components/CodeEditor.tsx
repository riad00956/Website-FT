import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Play, Save, Rocket, Plus, X, Code, Settings, FileText } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Project, ProjectFile } from "@shared/schema";

interface CodeEditorProps {
  project: Project | null;
}

export default function CodeEditor({ project }: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch project files
  const { data: files = [] } = useQuery<ProjectFile[]>({
    queryKey: ["/api/projects", project?.id, "files"],
    enabled: !!project?.id,
  });

  // Get active file
  const activeFile = files.find(f => f.isActive) || files[0];

  // Update file content mutation
  const updateFileMutation = useMutation({
    mutationFn: async ({ fileId, content }: { fileId: number; content: string }) => {
      if (!project) throw new Error("No project selected");
      await apiRequest("PATCH", `/api/projects/${project.id}/files/${fileId}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "files"] });
      toast({ title: "File saved successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to save file", description: error.message, variant: "destructive" });
    },
  });

  // Set active file mutation
  const setActiveFileMutation = useMutation({
    mutationFn: async (fileId: number) => {
      if (!project) throw new Error("No project selected");
      await apiRequest("PATCH", `/api/projects/${project.id}/files/${fileId}/activate`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", project?.id, "files"] });
    },
  });

  // Deploy project mutation
  const deployMutation = useMutation({
    mutationFn: async () => {
      if (!project) throw new Error("No project selected");
      const response = await apiRequest("POST", `/api/projects/${project.id}/deploy`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Deployment started", description: "Your project is being deployed..." });
      
      // Simulate console output
      setConsoleOutput(prev => [
        ...prev,
        "[INFO] Starting deployment...",
        "[INFO] Building project...",
        "[INFO] Deployment in progress..."
      ]);
    },
    onError: (error) => {
      toast({ title: "Deployment failed", description: error.message, variant: "destructive" });
    },
  });

  // Mock run function
  const handleRun = () => {
    if (!activeFile) return;
    
    setConsoleOutput([
      `[INFO] Running ${activeFile.fileName}...`,
      "[INFO] Process started",
      "[INFO] Listening for events...",
    ]);
    
    toast({ title: "Code execution started" });
  };

  const handleSave = () => {
    if (!activeFile || !editorRef.current) return;
    
    const content = editorRef.current.textContent || "";
    updateFileMutation.mutate({ fileId: activeFile.id, content });
  };

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.py')) return <Code className="w-4 h-4 text-yellow-500" />;
    if (fileName.endsWith('.js')) return <Code className="w-4 h-4 text-blue-500" />;
    if (fileName.endsWith('.html')) return <FileText className="w-4 h-4 text-orange-500" />;
    if (fileName.includes('config')) return <Settings className="w-4 h-4 text-gray-500" />;
    return <FileText className="w-4 h-4 text-gray-500" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running": return "bg-green-500";
      case "building": return "bg-yellow-500";
      case "stopped": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  if (!project) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background text-muted-foreground">
        <div className="text-center">
          <Code className="w-16 h-16 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No project selected</h3>
          <p>Select a project from the sidebar to start coding</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Editor Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-lg font-semibold">{project.name}</h1>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 ${getStatusColor(project.status)} rounded-full`}></div>
              <span className="text-sm text-muted-foreground capitalize">{project.status}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={handleSave} disabled={updateFileMutation.isPending}>
              <Save className="w-4 h-4 mr-1" />
              Save
            </Button>
            <Button variant="secondary" size="sm" onClick={handleRun}>
              <Play className="w-4 h-4 mr-1" />
              Run
            </Button>
            <Button size="sm" onClick={() => deployMutation.mutate()} disabled={deployMutation.isPending}>
              <Rocket className="w-4 h-4 mr-1" />
              Deploy
            </Button>
          </div>
        </div>
        
        {/* File Tabs */}
        <div className="flex items-center space-x-1 mt-4 border-b border-border">
          {files.map((file) => (
            <button
              key={file.id}
              onClick={() => setActiveFileMutation.mutate(file.id)}
              className={`px-3 py-2 text-sm flex items-center space-x-2 border-b-2 transition-colors ${
                file.isActive 
                  ? "border-primary bg-muted font-medium" 
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {getFileIcon(file.fileName)}
              <span>{file.fileName}</span>
            </button>
          ))}
          <button className="px-2 py-2 text-sm text-muted-foreground hover:text-foreground">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Code Editor */}
      <div className="flex-1 relative">
        <div className="absolute inset-0 bg-muted font-mono text-sm overflow-auto">
          <div 
            ref={editorRef}
            className="p-4 h-full min-h-full outline-none"
            contentEditable
            suppressContentEditableWarning
            style={{ whiteSpace: "pre", fontFamily: "JetBrains Mono, Monaco, Consolas, monospace" }}
          >
            {activeFile?.content || "// Start coding here..."}
          </div>
        </div>
      </div>

      {/* Console/Output Panel */}
      <div className="h-48 bg-card border-t border-border">
        <div className="flex items-center justify-between px-4 py-2 border-b border-border">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium">Console</span>
            {project.status === "running" && (
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-muted-foreground">Bot is running</span>
              </div>
            )}
          </div>
          <Button variant="ghost" size="sm" onClick={() => setConsoleOutput([])}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="p-4 font-mono text-sm text-muted-foreground h-40 overflow-y-auto">
          {consoleOutput.length === 0 ? (
            <div className="text-center text-muted-foreground mt-8">
              Console output will appear here...
            </div>
          ) : (
            consoleOutput.map((line, index) => (
              <div key={index} className={
                line.includes("[INFO]") ? "text-green-500" :
                line.includes("[ERROR]") ? "text-red-500" :
                line.includes("[DEBUG]") ? "text-blue-500" :
                "text-muted-foreground"
              }>
                {line}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
