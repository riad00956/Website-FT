import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Eye, EyeOff, ExternalLink, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Project, UpdateProject } from "@shared/schema";

interface SettingsPanelProps {
  project: Project | null;
}

interface EnvironmentVariable {
  key: string;
  value: string;
}

export default function SettingsPanel({ project }: SettingsPanelProps) {
  const [showBotToken, setShowBotToken] = useState(false);
  const [botToken, setBotToken] = useState(project?.botToken || "");
  const [customDomain, setCustomDomain] = useState(project?.customDomain || "");
  const [deploymentProvider, setDeploymentProvider] = useState(project?.deploymentProvider || "railway");
  const [envVars, setEnvVars] = useState<EnvironmentVariable[]>(() => {
    if (project?.environmentVariables && typeof project.environmentVariables === 'object') {
      return Object.entries(project.environmentVariables).map(([key, value]) => ({ key, value: String(value) }));
    }
    return [];
  });
  const [newEnvVar, setNewEnvVar] = useState<EnvironmentVariable>({ key: "", value: "" });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Update project mutation
  const updateProjectMutation = useMutation({
    mutationFn: async (data: UpdateProject) => {
      if (!project) throw new Error("No project selected");
      const response = await apiRequest("PATCH", `/api/projects/${project.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Project settings updated" });
    },
    onError: (error) => {
      toast({ title: "Failed to update settings", description: error.message, variant: "destructive" });
    },
  });

  const handleSaveSettings = () => {
    if (!project) return;

    const environmentVariables = Object.fromEntries(
      envVars.filter(env => env.key && env.value).map(env => [env.key, env.value])
    );

    updateProjectMutation.mutate({
      botToken: botToken || undefined,
      customDomain: customDomain || undefined,
      deploymentProvider,
      environmentVariables,
    });
  };

  const addEnvironmentVariable = () => {
    if (newEnvVar.key && newEnvVar.value) {
      setEnvVars(prev => [...prev, newEnvVar]);
      setNewEnvVar({ key: "", value: "" });
    }
  };

  const removeEnvironmentVariable = (index: number) => {
    setEnvVars(prev => prev.filter((_, i) => i !== index));
  };

  const formatTimeAgo = (date: string | null) => {
    if (!date) return "Never";
    const now = new Date();
    const updated = new Date(date);
    const diffInHours = Math.floor((now.getTime() - updated.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  if (!project) {
    return (
      <div className="w-80 bg-card border-l border-border p-4">
        <div className="text-center text-muted-foreground">
          <h3 className="text-lg font-semibold mb-2">Project Settings</h3>
          <p className="text-sm">Select a project to view settings</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border overflow-y-auto">
      <div className="p-4 border-b border-border">
        <h3 className="text-lg font-semibold mb-4">Project Settings</h3>
        
        {/* Bot Configuration */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="botToken" className="text-sm font-medium">Bot Token</Label>
            <div className="relative mt-2">
              <Input
                id="botToken"
                type={showBotToken ? "text" : "password"}
                placeholder="Enter your Telegram bot token..."
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
                onClick={() => setShowBotToken(!showBotToken)}
              >
                {showBotToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">Environment Variables</Label>
            <div className="space-y-2 mt-2">
              {envVars.map((envVar, index) => (
                <div key={index} className="flex space-x-2">
                  <Input
                    placeholder="KEY"
                    value={envVar.key}
                    onChange={(e) => {
                      const newVars = [...envVars];
                      newVars[index].key = e.target.value;
                      setEnvVars(newVars);
                    }}
                    className="flex-1"
                  />
                  <Input
                    type="password"
                    placeholder="VALUE"
                    value={envVar.value}
                    onChange={(e) => {
                      const newVars = [...envVars];
                      newVars[index].value = e.target.value;
                      setEnvVars(newVars);
                    }}
                    className="flex-1"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeEnvironmentVariable(index)}
                    className="h-10 w-10 p-0"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              <div className="flex space-x-2">
                <Input
                  placeholder="KEY"
                  value={newEnvVar.key}
                  onChange={(e) => setNewEnvVar(prev => ({ ...prev, key: e.target.value }))}
                  className="flex-1"
                />
                <Input
                  type="password"
                  placeholder="VALUE"
                  value={newEnvVar.value}
                  onChange={(e) => setNewEnvVar(prev => ({ ...prev, value: e.target.value }))}
                  className="flex-1"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={addEnvironmentVariable}
                className="w-full"
                disabled={!newEnvVar.key || !newEnvVar.value}
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Variable
              </Button>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">Deployment Provider</Label>
            <Select value={deploymentProvider} onValueChange={setDeploymentProvider}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="railway">Railway</SelectItem>
                <SelectItem value="firebase">Firebase Functions</SelectItem>
                <SelectItem value="vercel">Vercel</SelectItem>
                <SelectItem value="heroku">Heroku</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="customDomain" className="text-sm font-medium">Custom Domain</Label>
            <div className="flex mt-2">
              <Input
                id="customDomain"
                placeholder="subdomain"
                value={customDomain}
                onChange={(e) => setCustomDomain(e.target.value)}
                className="rounded-r-none border-r-0"
              />
              <span className="px-3 py-2 bg-muted text-sm text-muted-foreground border border-l-0 rounded-r-md">
                .codehost.app
              </span>
            </div>
          </div>

          <Button 
            onClick={handleSaveSettings} 
            disabled={updateProjectMutation.isPending}
            className="w-full"
          >
            {updateProjectMutation.isPending ? "Saving..." : "Save Settings"}
          </Button>
        </div>
      </div>

      {/* Deployment Status */}
      <div className="p-4 border-b border-border">
        <h4 className="text-sm font-semibold mb-3">Deployment Status</h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Status</span>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                project.status === "running" ? "bg-green-500" :
                project.status === "building" ? "bg-yellow-500" :
                "bg-gray-500"
              }`}></div>
              <span className={`text-sm capitalize ${
                project.status === "running" ? "text-green-600 dark:text-green-400" :
                project.status === "building" ? "text-yellow-600 dark:text-yellow-400" :
                "text-gray-600 dark:text-gray-400"
              }`}>
                {project.status}
              </span>
            </div>
          </div>
          
          {project.deploymentUrl && (
            <div className="flex items-center justify-between">
              <span className="text-sm">URL</span>
              <a 
                href={project.deploymentUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-sm text-primary hover:underline flex items-center space-x-1"
              >
                <span className="truncate max-w-32">
                  {project.deploymentUrl.replace('https://', '')}
                </span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <span className="text-sm">Last Deploy</span>
            <span className="text-sm text-muted-foreground">
              {formatTimeAgo(project.updatedAt)}
            </span>
          </div>
        </div>
      </div>

      {/* File Upload */}
      <div className="p-4">
        <h4 className="text-sm font-semibold mb-3">File Upload</h4>
        <Card className="border-2 border-dashed">
          <CardContent className="p-6 text-center">
            <div className="text-2xl text-muted-foreground mb-2">📁</div>
            <p className="text-sm text-muted-foreground mb-2">Drop files here or click to upload</p>
            <p className="text-xs text-muted-foreground">Supports .py, .js, .zip files</p>
            <input type="file" className="hidden" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
