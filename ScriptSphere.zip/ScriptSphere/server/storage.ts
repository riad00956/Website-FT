import {
  users,
  projects,
  projectFiles,
  adminLogs,
  type User,
  type UpsertUser,
  type Project,
  type ProjectFile,
  type AdminLog,
  type InsertProject,
  type InsertProjectFile,
  type UpdateProject,
  type InsertAdminLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Project operations
  getProjects(userId: string): Promise<Project[]>;
  getProject(id: number, userId: string): Promise<Project | undefined>;
  createProject(userId: string, project: InsertProject): Promise<Project>;
  updateProject(id: number, userId: string, project: UpdateProject): Promise<Project | undefined>;
  deleteProject(id: number, userId: string): Promise<boolean>;
  
  // Project file operations
  getProjectFiles(projectId: number, userId: string): Promise<ProjectFile[]>;
  getProjectFile(id: number, projectId: number, userId: string): Promise<ProjectFile | undefined>;
  createProjectFile(projectId: number, userId: string, file: InsertProjectFile): Promise<ProjectFile>;
  updateProjectFile(id: number, projectId: number, userId: string, content: string): Promise<ProjectFile | undefined>;
  deleteProjectFile(id: number, projectId: number, userId: string): Promise<boolean>;
  setActiveFile(projectId: number, fileId: number, userId: string): Promise<boolean>;
  
  // Admin operations
  getAdminLogs(projectId: number, userId: string): Promise<AdminLog[]>;
  createAdminLog(projectId: number, userId: string, action: string, details?: any): Promise<AdminLog>;
  getProjectStats(projectId: number, userId: string): Promise<{
    totalRuns: number;
    lastActivity: Date | null;
    memoryUsage: string | null;
    cpuUsage: string | null;
  } | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getProjects(userId: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.updatedAt));
  }

  async getProject(id: number, userId: string): Promise<Project | undefined> {
    const [project] = await db
      .select()
      .from(projects)
      .where(and(eq(projects.id, id), eq(projects.userId, userId)));
    return project;
  }

  async createProject(userId: string, project: InsertProject): Promise<Project> {
    const [newProject] = await db
      .insert(projects)
      .values({ ...project, userId })
      .returning();
    
    // Create default main file
    await db.insert(projectFiles).values({
      projectId: newProject.id,
      fileName: project.language === "python" ? "main.py" : project.language === "javascript" ? "index.js" : "index.html",
      content: this.getDefaultContent(project.language),
      language: project.language,
      isActive: true,
    });
    
    return newProject;
  }

  async updateProject(id: number, userId: string, project: UpdateProject): Promise<Project | undefined> {
    const [updatedProject] = await db
      .update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(and(eq(projects.id, id), eq(projects.userId, userId)))
      .returning();
    return updatedProject;
  }

  async deleteProject(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(projects)
      .where(and(eq(projects.id, id), eq(projects.userId, userId)));
    return (result.rowCount ?? 0) > 0;
  }

  // Project file operations
  async getProjectFiles(projectId: number, userId: string): Promise<ProjectFile[]> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return [];
    
    return await db
      .select()
      .from(projectFiles)
      .where(eq(projectFiles.projectId, projectId))
      .orderBy(desc(projectFiles.isActive), projectFiles.fileName);
  }

  async getProjectFile(id: number, projectId: number, userId: string): Promise<ProjectFile | undefined> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return undefined;
    
    const [file] = await db
      .select()
      .from(projectFiles)
      .where(and(eq(projectFiles.id, id), eq(projectFiles.projectId, projectId)));
    return file;
  }

  async createProjectFile(projectId: number, userId: string, file: InsertProjectFile): Promise<ProjectFile> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) throw new Error("Project not found");
    
    const [newFile] = await db
      .insert(projectFiles)
      .values({ ...file, projectId })
      .returning();
    return newFile;
  }

  async updateProjectFile(id: number, projectId: number, userId: string, content: string): Promise<ProjectFile | undefined> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return undefined;
    
    const [updatedFile] = await db
      .update(projectFiles)
      .set({ content, updatedAt: new Date() })
      .where(and(eq(projectFiles.id, id), eq(projectFiles.projectId, projectId)))
      .returning();
    return updatedFile;
  }

  async deleteProjectFile(id: number, projectId: number, userId: string): Promise<boolean> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return false;
    
    const result = await db
      .delete(projectFiles)
      .where(and(eq(projectFiles.id, id), eq(projectFiles.projectId, projectId)));
    return (result.rowCount ?? 0) > 0;
  }

  async setActiveFile(projectId: number, fileId: number, userId: string): Promise<boolean> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return false;
    
    // Set all files to inactive
    await db
      .update(projectFiles)
      .set({ isActive: false })
      .where(eq(projectFiles.projectId, projectId));
    
    // Set the specified file to active
    const result = await db
      .update(projectFiles)
      .set({ isActive: true })
      .where(and(eq(projectFiles.id, fileId), eq(projectFiles.projectId, projectId)));
    
    return (result.rowCount ?? 0) > 0;
  }

  // Admin operations
  async getAdminLogs(projectId: number, userId: string): Promise<AdminLog[]> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return [];
    
    return await db
      .select()
      .from(adminLogs)
      .where(eq(adminLogs.projectId, projectId))
      .orderBy(desc(adminLogs.timestamp))
      .limit(100);
  }

  async createAdminLog(projectId: number, userId: string, action: string, details?: any): Promise<AdminLog> {
    const [log] = await db
      .insert(adminLogs)
      .values({
        projectId,
        userId,
        action,
        details: details || {},
      })
      .returning();
    return log;
  }

  async getProjectStats(projectId: number, userId: string): Promise<{
    totalRuns: number;
    lastActivity: Date | null;
    memoryUsage: string | null;
    cpuUsage: string | null;
  } | undefined> {
    // First verify user owns the project
    const project = await this.getProject(projectId, userId);
    if (!project) return undefined;
    
    return {
      totalRuns: project.totalRuns,
      lastActivity: project.lastActivity,
      memoryUsage: project.memoryUsage,
      cpuUsage: project.cpuUsage,
    };
  }

  private getDefaultContent(language: string): string {
    switch (language) {
      case "python":
        return `import os
import telebot

# Telegram Bot Token
BOT_TOKEN = os.getenv('BOT_TOKEN')

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Hello! I'm your new bot.")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, message.text)

if __name__ == '__main__':
    bot.polling()`;
      case "javascript":
        return `const TelegramBot = require('node-telegram-bot-api');

const token = process.env.BOT_TOKEN;
const bot = new TelegramBot(token, {polling: true});

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Hello! I\\'m your new bot.');
});

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Received your message');
});`;
      case "html":
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
</head>
<body>
    <h1>Hello World!</h1>
    <p>Welcome to my website.</p>
</body>
</html>`;
      default:
        return "// Start coding here...";
    }
  }
}

export const storage = new DatabaseStorage();
