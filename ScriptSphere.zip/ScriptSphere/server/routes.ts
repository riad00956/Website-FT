import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProjectSchema, insertProjectFileSchema, updateProjectSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Project routes
  app.get("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projects = await storage.getProjects(userId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId, userId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(userId, validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.patch("/api/projects/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      const validatedData = updateProjectSchema.parse(req.body);
      
      const project = await storage.updateProject(projectId, userId, validatedData);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      console.error("Error updating project:", error);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      const success = await storage.deleteProject(projectId, userId);
      
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Project file routes
  app.get("/api/projects/:id/files", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      const files = await storage.getProjectFiles(projectId, userId);
      res.json(files);
    } catch (error) {
      console.error("Error fetching project files:", error);
      res.status(500).json({ message: "Failed to fetch project files" });
    }
  });

  app.get("/api/projects/:projectId/files/:fileId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.projectId);
      const fileId = parseInt(req.params.fileId);
      
      const file = await storage.getProjectFile(fileId, projectId, userId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.json(file);
    } catch (error) {
      console.error("Error fetching project file:", error);
      res.status(500).json({ message: "Failed to fetch project file" });
    }
  });

  app.post("/api/projects/:id/files", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      const validatedData = insertProjectFileSchema.parse(req.body);
      
      const file = await storage.createProjectFile(projectId, userId, validatedData);
      res.status(201).json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid file data", errors: error.errors });
      }
      console.error("Error creating project file:", error);
      res.status(500).json({ message: "Failed to create project file" });
    }
  });

  app.patch("/api/projects/:projectId/files/:fileId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.projectId);
      const fileId = parseInt(req.params.fileId);
      const { content } = req.body;
      
      if (typeof content !== 'string') {
        return res.status(400).json({ message: "Content must be a string" });
      }
      
      const file = await storage.updateProjectFile(fileId, projectId, userId, content);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.json(file);
    } catch (error) {
      console.error("Error updating project file:", error);
      res.status(500).json({ message: "Failed to update project file" });
    }
  });

  app.delete("/api/projects/:projectId/files/:fileId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.projectId);
      const fileId = parseInt(req.params.fileId);
      
      const success = await storage.deleteProjectFile(fileId, projectId, userId);
      
      if (!success) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting project file:", error);
      res.status(500).json({ message: "Failed to delete project file" });
    }
  });

  app.patch("/api/projects/:projectId/files/:fileId/activate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.projectId);
      const fileId = parseInt(req.params.fileId);
      
      const success = await storage.setActiveFile(projectId, fileId, userId);
      
      if (!success) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error setting active file:", error);
      res.status(500).json({ message: "Failed to set active file" });
    }
  });

  // Mock deployment endpoints
  app.post("/api/projects/:id/deploy", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      const project = await storage.getProject(projectId, userId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Mock deployment - update status to building then running
      await storage.updateProject(projectId, userId, { status: "building" });
      
      // Simulate deployment time
      setTimeout(async () => {
        const deploymentUrl = project.customDomain 
          ? `https://${project.customDomain}.codehost.app`
          : `https://${project.name.toLowerCase().replace(/\s+/g, '-')}-${projectId}.codehost.app`;
        
        await storage.updateProject(projectId, userId, { 
          status: "running",
          deploymentUrl
        });
      }, 3000);
      
      res.json({ message: "Deployment started", status: "building" });
    } catch (error) {
      console.error("Error deploying project:", error);
      res.status(500).json({ message: "Failed to deploy project" });
    }
  });

  app.post("/api/projects/:id/stop", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      const project = await storage.updateProject(projectId, userId, { status: "stopped" });
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Log admin action
      await storage.createAdminLog(projectId, userId, "stop", { previousStatus: project.status });
      
      res.json({ message: "Project stopped", status: "stopped" });
    } catch (error) {
      console.error("Error stopping project:", error);
      res.status(500).json({ message: "Failed to stop project" });
    }
  });

  // Admin panel routes
  app.get("/api/projects/:id/admin/logs", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      const logs = await storage.getAdminLogs(projectId, userId);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching admin logs:", error);
      res.status(500).json({ message: "Failed to fetch admin logs" });
    }
  });

  app.get("/api/projects/:id/admin/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      const stats = await storage.getProjectStats(projectId, userId);
      
      if (!stats) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching project stats:", error);
      res.status(500).json({ message: "Failed to fetch project stats" });
    }
  });

  app.post("/api/projects/:id/admin/restart", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectId = parseInt(req.params.id);
      
      // First stop, then start
      await storage.updateProject(projectId, userId, { status: "stopped" });
      
      setTimeout(async () => {
        await storage.updateProject(projectId, userId, { 
          status: "running",
          lastActivity: new Date()
        });
      }, 2000);

      // Log admin action
      await storage.createAdminLog(projectId, userId, "restart", { timestamp: new Date() });
      
      res.json({ message: "Project restarting", status: "restarting" });
    } catch (error) {
      console.error("Error restarting project:", error);
      res.status(500).json({ message: "Failed to restart project" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
